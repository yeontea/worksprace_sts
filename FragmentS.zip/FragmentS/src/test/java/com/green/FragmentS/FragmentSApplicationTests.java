package com.green.FragmentS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FragmentSApplicationTests {

	@Test
	void contextLoads() {
	}

}
