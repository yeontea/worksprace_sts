function addRow(){
    const fild = document.querySelector('.stu-list').querySelector('tbody');

    let stu ='';
    
    stu += '<tr>';
    stu += '<td><input type="text" class="stu"></td>';
    stu += '<td><input type="text" class="score"></td>';
    stu += '</tr>';

    fild.insertAdjacentHTML("afterbegin",stu);
}

function setData(){
    const scores = document.querySelectorAll('.score');
    const stus = document.querySelectorAll('.stu');
    const first = document.querySelector('#firstName');
    const bo = document.querySelector('#names');
    const total = document.querySelector('#totalScore');


    let sum = 0;
    for(const score of scores){
        sum = sum + parseInt(score.value);

    }
    total.value = sum;


    let s = 0;
    for(let i = 0; i < stus.length; i++){

        if(s<parseInt(scores[i].value)){

            s = parseInt(scores[i].value);


            first.value = stus[i].value;

        }
    }



    let final = '';
    for(let i = 0; i < stus.length; i++){
        if(parseInt(scores[i].value)<60){

            final += stus[i].value;
            final +=' ';

        }
        
    }
    bo.value = final;
    
    

}