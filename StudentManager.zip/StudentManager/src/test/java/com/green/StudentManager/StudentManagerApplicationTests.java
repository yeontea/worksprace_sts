package com.green.StudentManager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
